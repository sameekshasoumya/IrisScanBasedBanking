<?php
    include "validate_admin.php";
    include "header.php";
   
 include "user_navbar.php";
    include "admin_sidebar.php";
  include "session_timeout.php";
?>

<!DOCTYPE html>

<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admin_home_style.css">
</head>

<body>
    <div class="flex-container">
        <div class="flex-item">
            <h1 id="customer">
                WELCOME BACK, ADMIN!
          
  </h1>
   <p id="customer" style="max-width:800px">
         
        Iris Scan Bank(ISB) Admin<br><br>Admin can manage customers, view their transactions, update the news column and thus has all the power! 
		</p>
      
  </div>
    </div>

</body>
</html>
<?php include "easter_egg.php"; ?>
