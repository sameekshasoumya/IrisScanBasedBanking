<?php
    include "header.php";
    include "navbar.php";
?>

<!DOCTYPE html>
<html>
<head>
  
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="contact_style.css">
</head>

<body>
    <div class="flex-container-background">
      
  <div class="flex-container-heading">
            <h1 id="contact">Contact info</h1>
        </div>
      <div class="flex-container" style="border-bottom: 0;
                                     
      border-top-left-radius: 10px;
                                           border-top-right-radius: 10px;">
   
         <div class="flex-item">
                <h1 id="sub-contact">Corporate Headquarter</h1>
                <p id="sub-contact">
         
           Our Branches<br>IRIS SCAN BANK<br>
                  Corporate HQ: Patna, Bihar <br>
                  Our Other branches:<br> Mathura, Delhi, Dhanbad           </p>
  
          </div>
            <div class="flex-item">
                <h1 id="sub-contact">General Contact</h1>
                <p id="sub-contact">
             
       Toll-Free: 1515151515<br>
                    Phone: +5555555555<br>
                    <!--Fax: 123-123-123<br>-->
                    
     Email: simranchaudhary@gmail.com
                </p>
            </div>
        </div>

  
      <div class="flex-container" style="border-top: 0;
                                           border-bottom-left-radius: 10px;
        
                                   border-bottom-right-radius: 10px;">
            <div class="flex-item">
         
       <h1 id="sub-contact">Customer Care (24x7)</h1>
              
  <p id="sub-contact">
                    Toll-Free: 9999999999<br>
                    Phone: +1234567890<br>
      
              Email: sameekshasingh@gmail.com
                </p>
            </div>
            <div class="flex-item">
        
        <h1 id="sub-contact"> IN CASE OF ANY QUERY </h1>
                <p id="sub-contact">
     DO CONTACT US !            <br>
       
       WE ARE AVAILABLE 24 X 7 THROUGHOUT THE YEAR !<br>
 
 <p id="sub-contact">
 
In case of any doubt regarding project, contact to the above email.
 </p>
     
       </div>
   
     </div>
    </div>


</body>
</html>
