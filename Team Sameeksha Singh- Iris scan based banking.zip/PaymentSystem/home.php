<?php
    include "header.php";
    include "navbar.php";

    if (isset($_GET['loginFailed'])) 
	{
   $message = "Invalid User Credentials! Please try again.";
        echo "<script type='text/javascript'>alert('$message');</script>";
    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="stylesheet" href="home_style.css">
</head>
<body>
 
    <div class="flex-container-background">
        <div class="flex-container">
      
      <div class="flex-item-0">
                <h1 id="form_header"><marquee>PAYMENT PORTAL BY TEAM SAMEEKSHA SINGH</marquee></h1>
           
 </div>
        </div>

        <div class="flex-container">
            <div class="flex-item-1">
            
    <form action="customer_login_action.php" method="post">
                
    <div class="flex-item-login">
                        <center><h1>Welcome!</h1></center>
     
               </div>

                    <div class="flex-item">
                       
 <input type="text" name="cust_uname" placeholder="USERNAME" required>
                 
   </div>

                    <div class="flex-item">
                    
    <input type="password" name="cust_psw" placeholder="PASSWORD" required>
      
              </div>

                    <div class="flex-item">
                       
 <center><button type="submit">Click to Login</button></center>
                    </div>
                </form>
            </div>
 
       </div>

    </div>

</body>
</html>

<?php include "easter_egg.php"; ?>
